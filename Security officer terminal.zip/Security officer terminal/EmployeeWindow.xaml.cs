﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace Security_officer_terminal
{
    /// <summary>
    /// Логика взаимодействия для EmployeeWindow.xaml
    /// </summary>
    public partial class EmployeeWindow : Window
    {
        public EmployeeWindow()
        {
            InitializeComponent();
            using (var db = new KeeperPRO_KorotkikhEntities())
            {
                cmbep.ItemsSource = db.department.ToList();
                cmbep.DisplayMemberPath = "name";
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            UpdateApp();
        }
        /// <summary>
        /// Метод, который выводит все одобренные заявки
        /// </summary>
        private void UpdateApp()
        {
            using (var db = new KeeperPRO_KorotkikhEntities())
            {
                var query = from Application in db.application
                            join Application_visitor in db.application_visitor on Application.id_application equals Application_visitor.id_application
                            join Visitor in db.visitor on Application_visitor.id_visitor equals Visitor.id_visitor
                            join Department in db.department on Application.department equals Department.id_department
                            join Goal in db.goal on Application.goal equals Goal.id_goal
                            where Application.status == "одобрена"
                            select new
                            {
                                Номер = Application.id_application,
                                Датаоформлениязаявки = Application.date_of_application,
                                Началопропуска = Application.start_actions_application,
                                Конецпропуска = Application.end_actions_application,
                                Цель = Goal.name,
                                Статус = Application.status,
                                Отдел = Department.name,
                                Тип = Application.type,
                                Фамилия = Visitor.lastname,
                                Имя = Visitor.name,
                                Телефон = Visitor.phone,
                                серия = Visitor.series,
                            };
                dgspisok.ItemsSource = query.ToList();
            }
        }
        /// <summary>
        /// Логика фильтрации заявок по потразделениям
        /// </summary>
        //private void cmbep_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{
        //    using (var db = new KeeperPRO_KorotkikhEntities())
        //    {
        //        if (cmbep.SelectedIndex != -1)
        //        {
        //            string selectedDepartmentName = cmbep.SelectedValue.ToString();

        //            var query = from Application in db.application
        //                        join Department in db.department on Application.department equals Department.id_department
        //                        join Goal in db.goal on Application.goal equals Goal.id_goal
        //                        where Application.status == "одобрена" && Department.name == selectedDepartmentName
        //                        select new
        //                        {
        //                            Номер = Application.id_application,
        //                            Датаоформлениязаявки = Application.date_of_application,
        //                            Началопропуска = Application.start_actions_application,
        //                            Конецпропуска = Application.end_actions_application,
        //                            Цель = Goal.name,
        //                            Статус = Application.status,
        //                            Отделение = Department.name,
        //                            Тип = Application.type,
        //                        };
        //            dgspisok.ItemsSource = query.ToList();
        //        }
        //        else
        //        {
        //            MessageBox.Show("Выберите подразделение");
        //        }
        //    }
        //}

        private void btall_Click(object sender, RoutedEventArgs e)
        {
            UpdateApp();
        }
        /// <summary>
        /// Логика фильтрации заявок по дате оформления
        /// </summary>
        private void dp_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            using (var db = new KeeperPRO_KorotkikhEntities())
            {
                var selectedDate = dp.SelectedDate;
                var query = from Application in db.application
                            join Application_visitor in db.application_visitor on Application.id_application equals Application_visitor.id_application
                            join Department in db.department on Application.department equals Department.id_department
                            join Goal in db.goal on Application.goal equals Goal.id_goal
                            where Application.status == "одобрена" && Application.date_of_application == selectedDate
                            select new
                            {
                                Номер = Application.id_application,
                                Датаоформлениязаявки = Application.date_of_application,
                                Началопропуска = Application.start_actions_application,
                                Конецпропуска = Application.end_actions_application,
                                Цель = Goal.name,
                                Статус = Application.status,
                                Отделение = Department.name,
                                Тип = Application.type,
                            };
                dgspisok.ItemsSource = query.ToList();
            }
        }
        /// <summary>
        /// Поиск заявок по фамилии, имени и отчеству
        /// </summary>
        private void btpoisk_Click(object sender, RoutedEventArgs e)
        {
            string searchTerm = tb.Text.Trim();

            using (var db = new KeeperPRO_KorotkikhEntities())
            {
                var selectedDate = dp.SelectedDate;
                var query = from Application in db.application
                            join Application_visitor in db.application_visitor on Application.id_application equals Application_visitor.id_application
                            join Visitor in db.visitor on Application_visitor.id_visitor equals Visitor.id_visitor
                            join Department in db.department on Application.department equals Department.id_department
                            join Goal in db.goal on Application.goal equals Goal.id_goal
                            where Application.status == "одобрена" && (Visitor.lastname.Contains(searchTerm) ||
                             Visitor.name.Contains(searchTerm) ||
                             Visitor.surname.Contains(searchTerm))
                            select new
                            {
                                Номер = Application.id_application,
                                Датаоформлениязаявки = Application.date_of_application,
                                Началопропуска = Application.start_actions_application,
                                Конецпропуска = Application.end_actions_application,
                                Цель = Goal.name,
                                Статус = Application.status,
                                Отделение = Department.name,
                                Тип = Application.type,
                                Фамилия = Visitor.lastname,
                                Имя = Visitor.name,
                                Телефон = Visitor.phone,
                                серия = Visitor.series,
                            };
                dgspisok.ItemsSource = query.ToList();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
