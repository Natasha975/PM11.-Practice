﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Common.CommandTrees;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Desktop_app
{
    /// <summary>
    /// Логика взаимодействия для RegWindow.xaml
    /// </summary>
    public partial class RegWindow : Window
    {
        public RegWindow()
        {
            InitializeComponent();
        }

        private void btreg_Click(object sender, RoutedEventArgs e)
        {      
            using (var db = new KeeperPRO_KorotkikhEntities())
            {
                try
                {
                    var newVisitor = new visitor();
                    int maxIdVisitor = db.visitor.Max(u => u.id_visitor) + 1;

                    newVisitor.id_visitor = maxIdVisitor;
                    newVisitor.lastname = tblas.Text;
                    newVisitor.name = tbname.Text;
                    newVisitor.surname = tbsur.Text;
                    newVisitor.phone = tbphone.Text;
                    newVisitor.e_mail = tbemail.Text;
                    newVisitor.dirthday = dpBith.SelectedDate.Value;
                    newVisitor.organization = tborg.Text;
                    newVisitor.note = tbnote.Text;
                    newVisitor.photo = tbphoto.Text;
                    newVisitor.login = tblogin.Text;
                    newVisitor.password = tbpas.Text;
                    newVisitor.assign = tbass.Text;
                    int ser = int.Parse(tbser.Text);
                    int numb = int.Parse(tbnumb.Text);
                    newVisitor.series = ser;
                    newVisitor.number = numb;

                    var usern1 = db.visitor.FirstOrDefault(Users => Users.series == ser && Users.number == numb);
                    if (usern1 == null)
                    {
                        db.visitor.Add(newVisitor);
                        db.SaveChanges();
                        MessageBox.Show("Посетитель зарегистрирован!");
                    }
                    else
                    {
                        MessageBox.Show("Такой посетитель существует!");
                    }
                }
                catch (Exception ex) { MessageBox.Show("Ошибка при добавлении посетителя: " + ex.Message); }            
            }
        }

        private void btnasad_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
