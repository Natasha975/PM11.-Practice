﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace Desktop_app
{
    /// <summary>
    /// Логика взаимодействия для PersonalWindow.xaml
    /// </summary>
    public partial class PersonalWindow : Window
    {
        public PersonalWindow()
        {
            InitializeComponent();
            using (var db = new KeeperPRO_KorotkikhEntities())
            {
                List<string> departmentNames = db.department.Select(dep => dep.name).ToList();

                cbdepartment.ItemsSource = departmentNames;
            }
            
        }

        private void btphoto_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btfile_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btfillapp_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new KeeperPRO_KorotkikhEntities())
            {
                var newVisitor = new visitor();
                int maxIdVisitor = db.visitor.Max(u => u.id_visitor) + 1;

                newVisitor.id_visitor = maxIdVisitor;
                newVisitor.lastname = tblas.Text;
                newVisitor.name = tbname.Text;
                newVisitor.surname = tbsur.Text;
                newVisitor.phone = tbphone.Text;
                newVisitor.e_mail = tbemail.Text;
                newVisitor.dirthday = dpBith.SelectedDate.Value;
                newVisitor.organization = tborg.Text;
                newVisitor.note = tbnote.Text;
                newVisitor.photo = "";
                newVisitor.login = "asf";
                newVisitor.password = "dsgt";
                int ser = int.Parse(tbser.Text);
                int numb = int.Parse(tbnumb.Text);
                newVisitor.series = ser;
                newVisitor.number = numb;
                newVisitor.assign = "d123hu24";

                var usern1 = db.visitor.FirstOrDefault(Users => Users.series == ser && Users.number == numb);
                if (usern1 == null)
                {
                    db.visitor.Add(newVisitor);
                    db.SaveChanges();
                    MessageBox.Show("Посетитель добавлен!");
                }

                string selectedDepartmentName = cbdepartment.SelectedItem.ToString();
                var department = db.department.FirstOrDefault(dep => dep.name == selectedDepartmentName);
                try
                {
                    if (department != null)
                    {
                        var newApp = new application();

                        int maxIdApp = db.application.Max(u => u.id_application) + 1;
                        newApp.id_application = maxIdApp;

                        newApp.date_of_application = DateTime.Now;
                        newApp.start_actions_application = dpStart.SelectedDate.Value;
                        newApp.end_actions_application = dpStart.SelectedDate.Value;
                        newApp.goal = tbgoal.Text;
                        newApp.status = "проверка";
                        newApp.department = department.id_department;
                        newApp.type = "личное";
                        db.application.Add(newApp);
                        db.SaveChanges();

                        MessageBox.Show("Заявка успешно добавлена!");
                    }
                }
                catch (Exception ex) { MessageBox.Show("Ошибка: " + ex.Message); }
                try
                {
                    var newAppVis = new application_visitor();

                    int IdVisitor = db.application_visitor.Max(u => u.id_application) + 1;
                    int IdAppl = db.application.Max(u => u.id_application);
                    int IdVis = db.visitor.Max(u => u.id_visitor);

                    newAppVis.id_application_visitor = IdVisitor;
                    newAppVis.id_application = IdAppl;
                    newAppVis.id_visitor = IdVis;
                }
                catch (Exception ex) { MessageBox.Show("Ошибка: " + ex.Message); }
            }
            tbgoal.Text = "";
            tbFIO.Text = "";
            tblas.Text = "";
            tbname.Text = "";
            tbser.Text = "";
            tbphone.Text = "";
            tbemail.Text = "";
            tborg.Text = "";
            tbnote.Text = "";
            tbser.Text = "";
            tbnumb.Text = "";
        }

        private void btclear_Click(object sender, RoutedEventArgs e)
        {
            tbgoal.Text = "";
            tbFIO.Text = "";
            tblas.Text = "";
            tbname.Text = "";
            tbser.Text = "";
            tbphone.Text = "";
            tbemail.Text = "";
            tborg.Text = "";
            tbnote.Text = "";
            tbser.Text = "";
            tbnumb.Text = "";
        }

        private void btnasad_Click(object sender, RoutedEventArgs e)
        {
            TypeApplication typeApplication = new TypeApplication();
            typeApplication.Show();
            this.Close();
        }
    }
}
