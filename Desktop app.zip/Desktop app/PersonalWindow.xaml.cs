﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Desktop_app
{
    /// <summary>
    /// Логика взаимодействия для PersonalWindow.xaml
    /// </summary>
    public partial class PersonalWindow : Window
    {
        public PersonalWindow()
        {
            InitializeComponent();
            using (var db = new KeeperPRO_KorotkikhEntities())
            {
                cbdepartment.ItemsSource = db.department.Select(dep => dep.name.ToString());
            }

        }

        private void btphoto_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
