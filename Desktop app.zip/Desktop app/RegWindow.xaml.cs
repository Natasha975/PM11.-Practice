﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Desktop_app
{
    /// <summary>
    /// Логика взаимодействия для RegWindow.xaml
    /// </summary>
    public partial class RegWindow : Window
    {
        public RegWindow()
        {
            InitializeComponent();
        }

        private void btreg_Click(object sender, RoutedEventArgs e)
        {
            
            using (var db = new KeeperPRO_KorotkikhEntities())
            {
                var usern = new user();
                tbid.Text = usern.id_user.ToString();
                //int ID = db.user.LastOrDefault(Users=>Users.id_user == );
                //usern.id_user = ID;
                usern.lastname = tbfam.Text;
                usern.name = tbname.Text;
                usern.surname = tbsur.Text;
                usern.phone = tbphone.Text;
                usern.e_mail = tbemail.Text;
                usern.dirthday = DateTime.Now;
                usern.organization = tborgan.Text;
                usern.note = tbnote.Text;
                usern.photo = tbphoto.Text;
                usern.login = tblogin.Text;
                usern.password = tbpas.Text;
                usern.assign = tbas.Text;
                int ser = int.Parse(tbser.Text);
                int numb = int.Parse(tbnum.Text);
                usern.series = ser;
                usern.number = numb;

                var usern1 = db.user.FirstOrDefault(Users => Users.series == ser && Users.number == numb);
                if (usern1 == null)
                {
                    db.user.Add(usern);
                    db.SaveChanges();
                    MessageBox.Show("Вы успешно зарегистрировались!");
                }
                else
                {
                    MessageBox.Show("Такой логин существует!");
                }
            }
        }
    }
}
