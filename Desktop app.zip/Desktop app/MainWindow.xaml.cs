﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Desktop_app
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btauthorization_Click(object sender, RoutedEventArgs e)
        {

            using (var db = new KeeperPRO_KorotkikhEntities())
            {
                if (tbLogin.Text == null)
                {
                    MessageBox.Show("Неверно введен логин или пароль!");
                }
                else
                {
                    var usern = db.user.FirstOrDefault(Users => Users.login == tbLogin.Text && Users.password == tbPassword.Text);
                    var employeen = db.employee.FirstOrDefault(Employeen => Employeen.code == tbPassword.Text);

                    if (usern != null && employeen == null)
                    {
                        //MessageBox.Show("Вы посетитель");
                        TypeApplication typeApplication = new TypeApplication();
                        typeApplication.Show();
                        this.Hide();
                    }
                    else if (usern == null && employeen != null)
                    {
                        MessageBox.Show("Вы зашли как сотрудник");
                    }
                    else
                    {
                        MessageBox.Show("Неверно введен логин или пароль!");
                    }
                }
            }
        }

        private void btreg_Click(object sender, RoutedEventArgs e)
        {
            RegWindow regWindow = new RegWindow(); 
            regWindow.Show();
            this.Hide();
        }
    }
}
