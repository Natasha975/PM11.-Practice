﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Desktop_App__SQL_request_
{
    /// <summary>
    /// Логика взаимодействия для RegWindow.xaml
    /// </summary>
    public partial class RegWindow : Window
    {
        public RegWindow()
        {
            InitializeComponent();
        }

        private void btReg_Click(object sender, RoutedEventArgs e)
        {
            string connectionString = "Server=KAB17-02\\SQLEXPRESS;Database=KeeperPRO_Korotkikh;Trusted_Connection=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string maxIdQuery = "SELECT MAX(id_visitor) FROM visitor";

                    using (SqlCommand maxIdCommand = new SqlCommand(maxIdQuery, connection))
                    {
                        object result = maxIdCommand.ExecuteScalar();

                        int maxIdVisitor = (result == DBNull.Value || result == null) ? 0 : Convert.ToInt32(result);
                        maxIdVisitor++;

                        string query = @"INSERT INTO Visitor([id_visitor], lastname, name, surname, phone, [e-mail], birthday, series, number, organization, note, photo, purpose, login, password,assign, [scan_passport]) 
                                 VALUES (@idvisitor, @lastname, @name, @surname, @phone, @email, @birthday, @series, @number, @organization, @note, @photo, @purpose, @login, @password, @assign, @scan_passport)";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@idvisitor", maxIdVisitor);
                            command.Parameters.AddWithValue("@lastname", tblas.Text);
                            command.Parameters.AddWithValue("@name", tbname.Text);
                            command.Parameters.AddWithValue("@surname", tbsur.Text);
                            command.Parameters.AddWithValue("@phone", tbphone.Text);
                            command.Parameters.AddWithValue("@email", tbemail.Text);
                            command.Parameters.AddWithValue("@birthday", dpBith.SelectedDate);
                            command.Parameters.AddWithValue("@series", int.Parse(tbser.Text));
                            command.Parameters.AddWithValue("@number", int.Parse(tbnumb.Text));
                            command.Parameters.AddWithValue("@organization", tborg.Text);
                            command.Parameters.AddWithValue("@note", tbnote.Text);
                            command.Parameters.AddWithValue("@photo", tbphoto.Text);
                            command.Parameters.AddWithValue("@purpose", tbpur.Text);
                            command.Parameters.AddWithValue("@login", tblogin.Text);
                            command.Parameters.AddWithValue("@password", tbpas.Text);
                            command.Parameters.AddWithValue("@assign", tbass.Text);
                            command.Parameters.AddWithValue("@scan_passport", tbscan.Text);

                            int rowsAffected = command.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Посетитель успешно добавлен!");
                            }
                            else
                            {
                                MessageBox.Show("Не удалось добавить посетителя.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при добавлении посетителя: " + ex.Message);
                }
            }
        }
    }
}
