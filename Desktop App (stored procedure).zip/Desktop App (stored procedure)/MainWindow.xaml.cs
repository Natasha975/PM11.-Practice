﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Desktop_App__stored_procedure_
{
	/// <summary>
	/// Логика взаимодействия для MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void bt_Click(object sender, RoutedEventArgs e)
		{
			string log = tbLogin.Text;
			string pass = tbPass.Text;

			bool loginSuccessful = CheckLogin(log, pass);

			if (loginSuccessful)
				MessageBox.Show("Вы авторизовались под посетителем!");
			else
				MessageBox.Show("Неверный логин или пароль!");

		}
		/// <summary>
		/// Метод для проверки логина и пароля с использованием хранимой процедуры
		/// </summary>
		private bool CheckLogin(string username, string password)
		{
			try
			{
				string connectionString = "Server=DESKTOP-SDP8VA5;Database=KeeperPRO_Korotkikh;Trusted_Connection=True;";
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					connection.Open();
					SqlCommand command = new SqlCommand("prlogin", connection);
					command.CommandType = System.Data.CommandType.StoredProcedure;

					command.Parameters.AddWithValue("@login", username);
					command.Parameters.AddWithValue("@password", password);

					int count = (int)command.ExecuteScalar();

					return count > 0;
				}
			}
			catch (SqlException ex)
			{
				MessageBox.Show("Ошибка при выполнении запроса: " + ex.Message);
				return false;
			}
		}

		private void btreg_Click(object sender, RoutedEventArgs e)
		{
			RegWindow regWindow = new RegWindow();
			regWindow.Show();
		}
	}
}
