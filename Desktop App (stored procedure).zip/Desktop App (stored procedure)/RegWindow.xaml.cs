﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Desktop_App__stored_procedure_
{
	/// <summary>
	/// Логика взаимодействия для RegWindow.xaml
	/// </summary>
	public partial class RegWindow : Window
	{
		public RegWindow()
		{
			InitializeComponent();
		}

		private void btReg_Click(object sender, RoutedEventArgs e)
		{
			string connectionString = "Server=DESKTOP-SDP8VA5;Database=KeeperPRO_Korotkikh;Trusted_Connection=True;";

			using (SqlConnection connection = new SqlConnection(connectionString))
			{
				using (SqlCommand command = new SqlCommand("newvisitor", connection))
				{
					command.CommandType = CommandType.StoredProcedure;

					command.Parameters.Add("@idvisitor", SqlDbType.Int).Direction = ParameterDirection.Output;
					command.Parameters.AddWithValue("@lastname", tblas.Text);
					command.Parameters.AddWithValue("@name", tbname.Text);
					command.Parameters.AddWithValue("@surname", tbsur.Text);
					command.Parameters.AddWithValue("@phone", tbphone.Text);
					command.Parameters.AddWithValue("@email", tbemail.Text);
					command.Parameters.AddWithValue("@birthday", dpBith.SelectedDate);
					command.Parameters.AddWithValue("@series", int.Parse(tbser.Text));
					command.Parameters.AddWithValue("@number", int.Parse(tbnumb.Text));
					command.Parameters.AddWithValue("@organization", tborg.Text);
					command.Parameters.AddWithValue("@note", tbnote.Text);
					command.Parameters.AddWithValue("@photo", tbphoto.Text);
					command.Parameters.AddWithValue("@purpose", tbpur.Text);
					command.Parameters.AddWithValue("@login", tblogin.Text);
					command.Parameters.AddWithValue("@password", tbpas.Text);
					command.Parameters.AddWithValue("@assign", tbass.Text);
					command.Parameters.AddWithValue("@scan_passport", tbscan.Text);

					try
					{
						connection.Open();
						command.ExecuteNonQuery();

						MessageBox.Show("Посетитель успешно добавлен!");
					}
					catch (Exception ex)
					{
						MessageBox.Show("Ошибка при добавлении посетителя: " + ex.Message);
					}
				}
			}
		}
	}
}
